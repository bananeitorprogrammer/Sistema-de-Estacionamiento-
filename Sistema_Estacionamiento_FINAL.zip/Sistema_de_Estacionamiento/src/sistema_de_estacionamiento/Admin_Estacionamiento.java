/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/**
 *
 * @author anapa
 */
public class Admin_Estacionamiento {
    public static void guardarObjeto(ArrayList<Vehiculo> lista,String rutaArchivo){
        try (ObjectOutputStream escritorObjetos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))){
            escritorObjetos.writeObject(lista);
            System.out.println("Objeto Vehiculo serializado y guarddo");
        }catch (IOException e){
            System.err.println("Error al guadrar objeto: "+ e.getMessage());
        }
    }
    public static ArrayList<Vehiculo> leerObjeto(String rutaArchivo){
        try (ObjectInputStream lectorObjetos = new ObjectInputStream(new FileInputStream(rutaArchivo))){
            ArrayList<Vehiculo> listaVehiculorecuperado = (ArrayList<Vehiculo>) lectorObjetos.readObject();
            System.out.println("Objeto Estudiante recuperado con exito");
           return listaVehiculorecuperado;
        }catch (IOException e){
            System.err.println("Error de lectura: "+ e.getMessage());
           
        }catch (ClassNotFoundException e){
            System.err.println("La clase del objeto no fue encontarada" + e.getMessage());
        }
        return new ArrayList<>();
        
    }
    
}
