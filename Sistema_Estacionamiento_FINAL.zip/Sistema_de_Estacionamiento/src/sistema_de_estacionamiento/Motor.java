/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.io.Serializable;
/**
 *
 * @author anapa
 */
public class Motor implements Serializable{
    //Atributos de la clase Motor
    private int rpm;
    private String tipo_de_motor;
    private int potencia; 
    private int cilindros;
    
    //Constructor

    public Motor(int rpm, String tipo_de_motor, int potencia, int cilindros) {
        this.rpm = rpm;
        this.tipo_de_motor = tipo_de_motor;
        this.potencia = potencia;
        this.cilindros = cilindros;
    }
    
    //Gets y sets 

    public int getRpm() {
        return rpm;
    }

    public void setRpm(int rpm) {
        this.rpm = rpm;
    }

    public String getTipo_de_motor() {
        return tipo_de_motor;
    }

    public void setTipo_de_motor(String tipo_de_motor) {
        this.tipo_de_motor = tipo_de_motor;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public int getCilindros() {
        return cilindros;
    }

    public void setCilindros(int cilindros) {
        this.cilindros = cilindros;
    }
    
    //Métodos de la clase 
}
