/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.io.Serializable;
/**
 *
 * @author anapa
 */
public class Token implements Serializable{
    //Atributos de la clase 
    private int matricula;
    private Boolean acceso; 
    
    //Constructor 

    public Token(Boolean acceso) {
        this.matricula = (int)(Math.random() * 14000);
        this.acceso = acceso;
    }
    
    //gets y sets 

    public int getMatricula() {
        return matricula;
    }

    public Boolean getAcceso() {
        return acceso;
    }

    public void setAcceso(Boolean acceso) {
        this.acceso = acceso;
    }
    
    //Metodos 
}
