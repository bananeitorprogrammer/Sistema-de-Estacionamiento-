/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Date;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
/**
 *
 * @author anapa
 */
public class Administracion {
    static Scanner sc = new Scanner(System.in);
    ArrayList<Vehiculo> inventario = new ArrayList<>();
    public void MostrarMenu(){
        iniciar();
        Boolean control=true;
         while(control){
		try{
			System.out.println("-------BIENVENIDO AL SISTEMA DE ESTACIONAMIENTO-----------");
                	System.out.println("Por favor ingrese al opcion que desea realizar");
                	System.out.println("1)Registar un vehoculo nuevo");
                	System.out.println("2)Mostrar vehiculso registrados");
                	System.out.println("3)Registar entrada o salida al estacionamiento");
                	System.out.println("4)Mostarr histroial de accesos");
                	System.out.println("5)Salir");
                	int op=sc.nextInt();
                	sc.nextLine();
                	switch(op){
                    	case 1:
                        	CrearVehiculo();
                        	break;
                    	case 2:
                        	MostrarVehiculos();
                        	break;
                    	case 3: 
                        	try {
                            	    System.out.println("¿Que deseas registrar?");
                            	    System.out.println("1)Entrada");
                            	    System.out.println("2)Salida");
                            	    System.out.println("Ingresa la opcion que deseas realizar: ");
                            	    int opcion=sc.nextInt();
                                    sc.nextLine();
                            	    if(opcion==1){
                                	RegistrarEntrada();
                                	break;
                            	    }if (opcion==2){
                                	RegistrarSalida();
                                	break;
                                   }else{
                                	System.out.println("Opcion no valida");
                            	   }
                        	}catch (InputMismatchException e){
                            		System.out.println("Entrada invalida"+ e.getMessage());
                        	}
                        	break;
                    	case 4:
                        	MostrarHistorial();
                        	break;
                    	case 5:
                        	System.out.println("Saliendo del programa...");
                        	System.out.println("Guardando inventario de vehículos...");
                        	Admin_Estacionamiento.guardarObjeto(inventario, "inventario.dat");
                                control=false;
                        	break;
				
                    	default:
                        	System.out.println("Opcion Invalid apor favor introduce una opcion valida...");
                        	
                        	break;
                	}
            	}catch (InputMismatchException e){
            		System.out.println("Entrada Invalida..."+e.getMessage());
                        sc.nextLine();
        	}
        }         
    }
    public void CrearVehiculo(){
            Boolean control=true;
            while(control){
                try{
                    System.out.println("-----------REGISTRANDO VEHICULO-----------");
                    System.out.println("Ingresa el tipo de vehiculoq ue quieres registrar");
                    System.out.println("1)Auto");
                    System.out.println("2)Moto");
                    System.out.println("3)Salir");
                    int op =sc.nextInt();
                    sc.nextLine();
                    if (op==1){
                        System.out.println("Ingrese la informacion del motor");
                        System.out.println("Revoluciones por minuto: ");
                        int rpm=sc.nextInt();
                        sc.nextLine();
                        System.out.println("Ingresa le tipo de motor: ");
                        String tipo_motor=sc.nextLine();
                        System.out.println("Ingresa la potencia dle motor: ");
                        int potencia=sc.nextInt();
                        System.out.println("Ingresa los cilindros: ");
                        int cilindros=sc.nextInt();
                        sc.nextLine();
                        Motor motornuevo = new Motor (rpm,tipo_motor,potencia,cilindros);
                        System.out.println("Ingres ale numero de placas: ");
                        String num_placas=sc.nextLine();
                        System.out.println("Ingresa la marca del auto: ");
                        String Marca=sc.nextLine();
                        System.out.println("Ingresa le modelo dle auto: ");
                        String Modelo=sc.nextLine();
                        System.out.println("Ingresa le color del auto: ");
                        String Color=sc.nextLine();
                        System.out.println("Ingresa el numero de llantas dle auto: ");
                        int num_llantas=sc.nextInt();
                        System.out.println("Ingresa el numeor de puertas que existen: ");
                        int num_puertas=sc.nextInt();
                        Auto autonuevo = new Auto (num_placas,Marca,Color,Modelo,motornuevo,num_llantas,num_puertas);
                        inventario.add(autonuevo);
                        System.out.println("Auto registrado con exito!!");
                        control=false;
                    }if(op==2){
                        System.out.println("Ingrese la informacion del motor");
                        System.out.println("Revoluciones por minuto: ");
                        int rpm=sc.nextInt();
                        System.out.println("Ingresa le tipo de motor: ");
                        String tipo_motor=sc.nextLine();
                        System.out.println("Ingresa la potencia dle motor: ");
                        int potencia=sc.nextInt();
                        System.out.println("Ingresa los cilindros: ");
                        int cilindros=sc.nextInt();
                        sc.nextLine();
                        Motor motornuevo = new Motor (rpm,tipo_motor,potencia,cilindros);
                        System.out.println("Ingres ale numero de placas: ");
                        String num_placas=sc.nextLine();
                        System.out.println("Ingresa la marca del moto: ");
                        String Marca=sc.nextLine();
                        System.out.println("Ingresa le color del moto: ");
                        String Color=sc.nextLine();
                        System.out.println("Ingresa el modleo de la moto: ");
                        String Modelo=sc.nextLine();
                        System.out.println("La moto cuenta con casco: (true/false) ");
                        Boolean casco=sc.nextBoolean();
                        System.out.println("La moto cuenta con luces: (true/false)");
                        Boolean luces=sc.nextBoolean();
                        Moto motonueva = new Moto (num_placas,Marca,Color,Modelo,motornuevo,casco,luces);
                        inventario.add(motonueva);
                        System.out.println("Moto registrada con exito!!");
                        control=false;
                    }if (op==3){
                        System.out.println("Saliendo....");
                        control=false;
                    }else{
                        System.out.println("Opcion Invalida");
                    }
                } catch(InputMismatchException e){
                    System.out.println("Entrada no valida"+ e.getMessage());
                    sc.nextLine();
                    }
        }
    }
    
    public void MostrarVehiculos(){
        System.out.println("---------------VEHICULOS REGISTRADOS-----------");
        if (inventario.isEmpty()){
            System.out.println("Aun no hay vehiculos registrados en el sistema");
        }else{
            for(Vehiculo i: inventario){
                System.out.println(i);
                System.out.println("---------------------------------");
            }
        }
    }
    
    public void RegistrarEntrada(){
        System.out.println("-------------REGISTRAR ENTRADA--------------");
        System.out.println("Ingresa la placa del vehiculo que etsa ingresando al estacionamiento: ");
        String placa=sc.nextLine();
        Date fecha_hoy= new Date();
        
        try(BufferedWriter escritor_archivo = new BufferedWriter(new FileWriter("accesos_diarios.txt",true))){
            String registro_entrada ="{"+fecha_hoy+"]-Entrada - Placa: " + placa;
            escritor_archivo.write(registro_entrada);
            escritor_archivo.newLine();
            System.out.println("Registro guardado exitosamente!!");
            
        }catch (IOException e){
            System.out.println("Error en el archivo"+e.getMessage());
        }catch (InputMismatchException e){
            System.out.println("Entrada Invalida.."+e.getMessage());
        }
    }
    
    public void RegistrarSalida(){
        System.out.println("----------------REGISTRAR SALIDA-------------");
        System.out.println("Ingresa la placa dle vehiculo: ");
        String placa=sc.nextLine();
        Boolean puedeSalir = false;
        try (BufferedReader lector = new BufferedReader(new FileReader("accesos_diarios.txt"))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.contains("Placa: " + placa)) {
                    if (linea.contains("ENTRADA")) {
                        puedeSalir = true;
                    } else if (linea.contains("SALIDA")) {
                        puedeSalir = false;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Aún no hay registros en la bitácora.");
        }
        if (puedeSalir) {
            Date fecha_sal = new Date();
            try (BufferedWriter escritor_archivo = new BufferedWriter(new FileWriter("accesos_diarios.txt", true))) {
                String salida = "[" + fecha_sal + "] - SALIDA - Placa: " + placa;
                escritor_archivo.write(salida);
                escritor_archivo.newLine();
                System.out.println("Salida registrada exitosamente.");
            } catch (IOException e) {
                System.out.println("Error al guardar: " + e.getMessage());
            }
        } else {
            System.out.println("Error: El vehículo con placa " + placa + " no se encuentra en el estacionamiento (no ha entrado o ya salió).");
        }
    }
    public void MostrarHistorial() {
        System.out.println("----------- HISTORIAL DE ACCESOS -----------");
        try (BufferedReader lector = new BufferedReader(new FileReader("accesos_diarios.txt"))) {
            String linea;
            boolean hayRegistros = false;
            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
                hayRegistros = true;
            }
            if (!hayRegistros) {
                System.out.println("La bitácora está vacía. Aún no hay accesos hoy.");
            }
        } catch (IOException e) {
            System.out.println("Aún no hay una bitácora creada en el sistema.");
        }
        System.out.println("--------------------------------------------");
    }
    
    public void iniciar(){
        System.out.println("Cargando sistema...");
        inventario = Admin_Estacionamiento.leerObjeto("inventario.dat");
        if (inventario.isEmpty()){
            System.out.println("No hay inventario previo. Iniciando sistema en limpio.");
        } else {
            System.out.println("¡Inventario cargado con éxito! Vehículos actuales: " + inventario.size());
        }
    }
}
