/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.io.Serializable;

/**
 *
 * @author anapa
 */
public class Moto extends Vehiculo implements Serializable{
    //Atributos 
    private Boolean casco;
    private Boolean luces;
    
    //Constructor 
    public Moto(String num_placas, String Marca, String Color, String Modelo, Motor motor, Boolean casco, Boolean luces) {
        super(num_placas, Marca, Color, Modelo, motor);
        this.casco=casco;
        this.luces=luces;
    }
    
    //gets y sets 

    public Boolean getCasco() {
        return casco;
    }

    public void setCasco(Boolean casco) {
        this.casco = casco;
    }

    

    public Boolean getLuces() {
        return luces;
    }

    public void setLuces(Boolean luces) {
        this.luces = luces;
    }

    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
    //Metodos 
}
