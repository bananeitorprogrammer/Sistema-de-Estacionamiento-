/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.io.Serializable;
/**
 *
 * @author anapa
 */
public class Vehiculo implements Serializable {
    //Atributos de la clase padre 
    private String num_placas;
    private String Marca;
    private String Color;
    private String Modelo;
    transient  Token token;
    Motor motor;

    //Constructor 

    public Vehiculo(String num_placas, String Marca, String Color, String Modelo,Motor motor) {
        this.num_placas = num_placas;
        this.Marca = Marca;
        this.Color = Color;
        this.Modelo = Modelo;
        this.token = new Token(true);
        this.motor = motor;
    }
    
    //Gets y sets 

    public String getNum_placas() {
        return num_placas;
    }

    public void setNum_placas(String num_placas) {
        this.num_placas = num_placas;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
    //Metodos 
    @Override
    public String toString(){
         return "Vehiculo [Numero de placas: "+num_placas+"\nMarca: "+ Marca + "\nColor: "+Color+"\nModelo: "+Modelo +"\nToken: "+token;
        
    }
    
}
