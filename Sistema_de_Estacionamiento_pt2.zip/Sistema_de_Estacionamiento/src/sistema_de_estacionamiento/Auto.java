/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;

import java.util.Date;

/**
 *
 * @author anapa
 */
public class Auto extends Vehiculo {
    //Atributos 
    private int num_llantas;
    private int num_puertas;
    
    //Constructor
    public Auto(String num_placas, String Marca, String Color, String Modelo, Date fecha_entrada, Date fecha_salida, Motor motor, int num_llantas, int num_puertas) {
        super(num_placas, Marca, Color, Modelo, fecha_entrada, fecha_salida, motor);
        this.num_llantas=num_llantas;
        this.num_puertas=num_puertas;
    }
   
    //fets y sets 

    public int getNum_llantas() {
        return num_llantas;
    }

    public void setNum_llantas(int num_llantas) {
        this.num_llantas = num_llantas;
    }

    public int getNum_puertas() {
        return num_puertas;
    }

    public void setNum_puertas(int num_puertas) {
        this.num_puertas = num_puertas;
    }

    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
}
