/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;

import java.util.Date;

/**
 *
 * @author anapa
 */
public class Moto extends Vehiculo{
    //Atributos 
    private String casco;
    private Boolean luces;
    
    //Constructor 
    public Moto(String num_placas, String Marca, String Color, String Modelo, Date fecha_entrada, Date fecha_salida, Motor motor) {
        super(num_placas, Marca, Color, Modelo, fecha_entrada, fecha_salida, motor);
        this.casco=casco;
        this.luces=luces;
    }
    
    //gets y sets 

    public String getCasco() {
        return casco;
    }

    public void setCasco(String casco) {
        this.casco = casco;
    }

    public Boolean getLuces() {
        return luces;
    }

    public void setLuces(Boolean luces) {
        this.luces = luces;
    }

    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
    //Metodos 
}
