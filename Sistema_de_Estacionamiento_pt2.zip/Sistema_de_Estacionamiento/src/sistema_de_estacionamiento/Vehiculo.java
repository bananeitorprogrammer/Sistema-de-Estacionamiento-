/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_estacionamiento;
import java.util.Date;
/**
 *
 * @author anapa
 */
public class Vehiculo {
    //Atributos de la clase padre 
    private String num_placas;
    private String Marca;
    private String Color;
    private String Modelo;
    private Date fecha_entrada;
    private Date fecha_salida;
    transient  Token token;
    Motor motor;

    //Constructor 

    public Vehiculo(String num_placas, String Marca, String Color, String Modelo, Date fecha_entrada, Date fecha_salida,Motor motor) {
        this.num_placas = num_placas;
        this.Marca = Marca;
        this.Color = Color;
        this.Modelo = Modelo;
        this.fecha_entrada = fecha_entrada;
        this.fecha_salida = fecha_salida;
        this.token = new Token(true);
        this.motor = motor;
    }
    
    //Gets y sets 

    public String getNum_placas() {
        return num_placas;
    }

    public void setNum_placas(String num_placas) {
        this.num_placas = num_placas;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public Date getFecha_entrada() {
        return fecha_entrada;
    }

    public void setFecha_entrada(Date fecha_entrada) {
        this.fecha_entrada = fecha_entrada;
    }

    public Date getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(Date fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
    //Metodos 
    @Override
    public String toString(){
         return "Vehiculo [Numero de placas: "+num_placas+"\nMarca: "+ Marca + "\nColor: "+Color+"\nModelo: "+Modelo +"\nFecha de entrada: "+fecha_entrada+"\nFecha Salida: ";
        
    }
    
}
