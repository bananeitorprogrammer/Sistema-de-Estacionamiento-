/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package serializacion;

/**
 *
 * @author anapa
 */
import java.util.ArrayList;

public class Serializacion {
    public static void main(String[] args) {
        String archivo = "estudiantes_data.ser";
        ArrayList<Estudinate> lista = new ArrayList<>();
        
        lista.add(new Estudinate("Ana", 20, "ana@cetys.mx", "secret123"));
        lista.add(new Estudinate("Ronald", 19, "ronald@cetys.mx", "pass456"));

        // Guardar lista
        Admin_Serie.guardarObjetos(lista, archivo);

        // Recuperar lista
        ArrayList<Estudinate> listaRecuperada = Admin_Serie.leerObjetos(archivo);

        if (listaRecuperada != null) {
            System.out.println("--- Datos Recuperados ---");
            for (Estudinate est : listaRecuperada) {
                System.out.println(est);
            }
        }
    }
}