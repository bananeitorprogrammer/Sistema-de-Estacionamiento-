/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package serializacion;

/**
 *
 * @author anapa
*/
import java.io.*;
import java.util.ArrayList;

public class Admin_Serie {

    // Función para guardar la lista completa 
    public static void guardarObjetos(ArrayList<Estudinate> lista, String nombreArchivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            out.writeObject(lista);
            System.out.println("Éxito: ArrayList serializado en " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error de serialización: " + e.getMessage());
        }
    }

    // Función para leer la lista completa 
    @SuppressWarnings("unchecked")
    public static ArrayList<Estudinate> leerObjetos(String nombreArchivo) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            return (ArrayList<Estudinate>) in.readObject(); // Casting necesario 
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error de deserialización: " + e.getMessage());
            return null;
        }
    }
}
