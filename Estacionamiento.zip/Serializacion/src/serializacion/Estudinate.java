/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package serializacion;

/**
 *
 * @author anapa
 */
public class Estudinate {
    private String nombre;
    private int edad;
    private String correo;
    private transient String contrasena;

    public Estudinate(String nombre, int edad, String correo, String contrasena) {
        this.nombre = nombre;
        this.edad = edad;
        this.correo = correo;
        this.contrasena = contrasena;
    }
    
    @Override
    public String toString(){
         return "Estudiante [nombre= "+ nombre + ", edad= " + edad + ", correo= "+ correo +", contrasena= "+ contrasena;
        
    }
}
