/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package serializacion;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author anapa
 */
public class AdministrarSerializacion {
    public static void guardarObjeto(Estudinate estudiante,String rutaArchivo){
        try (ObjectOutputStream escritorObjetos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))){
            escritorObjetos.writeObject(estudiante);
            System.out.println("Objeto estudiante serializado y guarddo");
        }catch (IOException e){
            System.err.println("Error al guadrar objeto: "+ e.getMessage());
        }
    }
    public static Estudinate leerObjeto(String rutaArchivo){
        try (ObjectInputStream lectorObjetos = new ObjectInputStream(new FileInputStream(rutaArchivo))){
            Estudinate estudianteRecuperado =(Estudinate) lectorObjetos.readObject();
            System.out.println("Objeto Estudiante recuperado con exito");
           return estudianteRecuperado;
        }catch (IOException e){
            System.err.println("Error de lectura: "+ e.getMessage());
           
        }catch (ClassNotFoundException e){
            System.err.println("La clase del objeto no fue encontarada" + e.getMessage());
        }
        return null;
        
    }
}
